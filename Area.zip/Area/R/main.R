#' Area Functions
#'
#' @param a dimension1
#' @param b dimension2
#'
#' @return returns Area
#'
#' @export
#'
#' @examples
#' Area2C(3,4)
#'
#'@useDynLib Area AreaC
Area2C <- function(a, b) {
  .Call("AreaC", a, b, PACKAGE = "Area")
}



#' Title
#'
#' @param a dim1
#' @param b dim2
#'
#' @return Area
#' @export
#'
#'
#' @examples
#' AreaR(4,5)
AreaR <- function(a,b){
  return( a*b )
}

